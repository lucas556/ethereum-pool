var headerFont = header_google_fonts.headerFont;
var mobileHeaderFont = header_google_fonts.mobileHeaderFont;

WebFont.load({ google: {families: [headerFont]}});
WebFont.load({ google: {families: [mobileHeaderFont]}});